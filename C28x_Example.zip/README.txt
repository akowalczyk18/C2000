You'll want to import the zip file into CCS, it should open as a normal project
It was madu using CCS 8.1, so I'd recommend using that or newer if you can.

Annotations are on 'led_ex1_blinky.c'


Let me know if you have any questions!